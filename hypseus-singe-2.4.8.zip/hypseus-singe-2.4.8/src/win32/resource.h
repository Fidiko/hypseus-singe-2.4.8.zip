//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by hypseus.rc
//
#define IDC_CHECK1                      1000
#define IDC_A0                          1000
#define IDC_CHECK2                      1001
#define IDC_A1                          1001
#define IDC_CHECK3                      1002
#define IDC_A2                          1002
#define IDC_CHECK4                      1003
#define IDC_A3                          1003
#define IDC_CHECK5                      1004
#define IDC_A4                          1004
#define IDC_CHECK6                      1005
#define IDC_A5                          1005
#define IDC_CHECK7                      1006
#define IDC_A6                          1006
#define IDC_CHECK8                      1007
#define IDC_A7                          1007
#define IDC_CHECK9                      1008
#define IDC_B0                          1008
#define IDC_CHECK10                     1009
#define IDC_B1                          1009
#define IDC_CHECK11                     1010
#define IDC_B2                          1010
#define IDC_CHECK12                     1011
#define IDC_B3                          1011
#define IDC_CHECK13                     1012
#define IDC_B4                          1012
#define IDC_CHECK14                     1013
#define IDC_B5                          1013
#define IDC_CHECK15                     1014
#define IDC_B6                          1014
#define IDC_CHECK16                     1015
#define IDC_B7                          1015
#define IDC_EDIT1                       1016
#define IDC_FILEMASK                    1016
#define IDC_EDIT3                       1019
#define IDC_LATENCY                     1019
#define IDC_RADIO1                      1020
#define IDC_RADIO2                      1021
#define IDC_RADIO3                      1022
#define IDC_RADIO4                      1023
#define IDC_RADIO5                      1024
#define IDC_RADIO6                      1025
#define IDC_RADIO7                      1026
#define IDC_RADIO8                      1027
#define IDC_RADIO9                      1028
#define IDC_RADIO10                     1029
#define IDC_LIST2                       1030
#define IDM_BOOT                        1031
#define IDM_CONFIGURE                   1032
#define IDM_EXIT                        1033
#define IDC_LDP                         1033
#define IDM_HELP                        1034
#define IDC_COMPORT                     1034
#define IDM_ABOUT                       1035
#define IDC_BAUD                        1035
#define IDD_RED                         1036
#define IDC_PRESET                      1036
#define IDD_GREEN                       1037
#define IDC_APPLY                       1037
#define IDD_BLUE                        1038
#define IDC_SKILL                       1038
#define IDC_DEBUG                       1039
#define IDC_FRAMEMODS                   1040
#define IDC_SCOREBOARD                  1041

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
